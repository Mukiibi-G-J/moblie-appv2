const background_01 = require('../assets/images/background_01.png');
const background_02 = require('../assets/images/background_02.png');
const card = require('../assets/images/card.png');
const favourite_food = require('../assets/images/favourite_food.png');
const great_food = require('../assets/images/great_food.png');
const hot_delivery = require('../assets/images/hot_delivery.png');
const logo_01 = require('../assets/images/logo_01.png');
const logo_02 = require('../assets/images/logo_02.png');
const profile = require('../assets/images/profile.png');
const success = require('../assets/images/success.png');
const coupon = require('../assets/images/coupon.png');
const logo_zentro = require('../assets/images/logo.png');
const logo_icon = require('../assets/images/logo-icon.png');
const profile2 = require('../assets/images/profile2.png');
const person = require('../assets/images/person.png');
// const semunalogo = require('../assets/images/semunalogo.png');

export default {
  background_01,
  background_02,
  card,
  favourite_food,
  great_food,
  hot_delivery,
  logo_01,
  logo_02,
  profile,
  success,
  coupon,
  logo_zentro,
  logo_icon,
  profile2,
  person,
  // semunalogo,
};
